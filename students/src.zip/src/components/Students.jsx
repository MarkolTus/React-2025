function Students({students, deleteStudentV}) {

  return (
    <>
      <h1>Students</h1>
      <table><tbody>
        {
          students.map(
            student => (
              <tr key={student.id}>
                <td>{student.studentId}</td>
                <td>{student.name}</td>
                <td>{student.email}</td>
                <td>
                  <button onClick={deleteStudentV} value={student.id}>Delete</button>
                </td>
              </tr>
            )
          )
        }
        </tbody>
      </table>
    </>
  )
}

export default Students